weather
=======

利用中央气象台的API做的一款天气预报App

在assets目录下的data.db为中央气象台全国各个城市和地区的城市码

中央气象台API使用示例请参考 http://g.kehou.com/t1029846752.html

中央气象台城市码请参考 http://blog.163.com/yuanzhf_2012/blog/static/2112011482012929454663/

![Screenshot](https://github.com/liumeng1201/weather/raw/master/weather1.png)

![Screenshot](https://github.com/liumeng1201/weather/raw/master/weather2.png)
